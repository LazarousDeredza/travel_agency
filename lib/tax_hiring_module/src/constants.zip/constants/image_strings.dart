const String tSplashTopIcon = 'assets/images/integrity_link_logo2.png';
const String tSplashImage = 'assets/images/integrity_link_logo3.png';
const String tSplashImage2 = 'assets/images/icon1.png';
//onboarding screen images

const String tOnboardingImage1 =
    'assets/images/on_boarding_images/onboarding1.jpg';
const String tOnboardingImage2 =
    'assets/images/on_boarding_images/onboarding2.jpg';
const String tOnboardingImage3 =
    'assets/images/on_boarding_images/onboarding3.jpg';

//welcome screen images
//also used in login and signup screens

const String tWelcomeScreenImage =
    'assets/images/welcome_images/welcome_screen_image.png';

//login screen images
const String tGoogleLogoImage = 'assets/logo/google_logo.png';

//forgot password screen images
const String tForgotPasswordImage =
    'assets/images/forgot_password/forgot_password.png';

//signup screen images
const String tProfileImage = 'assets/images/profiles/profile_blank.png';

const String tGroupImage = 'assets/images/profiles/group.png';

const String tCameraImage = 'assets/images/camera.png';
